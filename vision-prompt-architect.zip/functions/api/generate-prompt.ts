import { GoogleGenAI } from "@google/genai";

interface Env {
  GEMINI_API_KEY: string;
}

export const onRequestPost: any = async (context: any) => {
  try {
    const { GEMINI_API_KEY } = context.env;
    if (!GEMINI_API_KEY) {
      return new Response(JSON.stringify({ error: "GEMINI_API_KEY not configured in Cloudflare" }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }

    const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
    const options = await context.request.json() as any;

    const { 
      gender, expression, shotType, cameraAngle, pose, 
      background, artStyle, lighting, colorTone, additionalDescription,
      mainImage, mainImageMimeType, faceImage, faceImageMimeType 
    } = options;

    const systemInstruction = `You are an expert prompt engineer for AI image generators. 
Your task is to analyze the provided images (if any) and combine them with the user's selected options to create a high-quality, detailed English prompt for image generation.

If images are provided:
- Analyze the character's appearance, clothing, and features from the main image.
- If a face image is provided, focus on the facial details and expressions.

Incorporate the following parameters into the prompt:
- Gender/Character Type
- Facial Expression
- Shot Type
- Camera Angle
- Character Pose
- Background/Location
- Art Style
- Lighting
- Color Tone
- Any additional descriptions.

Output ONLY the final prompt text in English.`;

    const parts: any[] = [];

    if (mainImage && mainImageMimeType) {
      parts.push({
        inlineData: {
          mimeType: mainImageMimeType,
          data: mainImage.split(',')[1],
        },
      });
    }

    if (faceImage && faceImageMimeType) {
      parts.push({
        inlineData: {
          mimeType: faceImageMimeType,
          data: faceImage.split(',')[1],
        },
      });
    }

    const promptText = `Generate a professional image generation prompt based on these settings:
- Gender: ${gender || 'Not specified'}
- Expression: ${expression || 'Not specified'}
- Shot Type: ${shotType || 'Not specified'}
- Camera Angle: ${cameraAngle || 'Not specified'}
- Pose: ${pose || 'Not specified'}
- Background: ${background || 'Not specified'}
- Art Style: ${artStyle || 'Not specified'}
- Lighting: ${lighting || 'Not specified'}
- Color Tone: ${colorTone || 'Not specified'}
- Additional Info: ${additionalDescription || 'None'}`;

    parts.push({ text: promptText });

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: { parts },
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return new Response(JSON.stringify({ text: response.text }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error: any) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
};
