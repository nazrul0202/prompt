import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // API routes FIRST
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.post("/api/generate-prompt", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "GEMINI_API_KEY not configured" });
      }

      const ai = new GoogleGenAI({ apiKey });
      const options = req.body;

      const { 
        gender, expression, shotType, cameraAngle, pose, 
        background, artStyle, lighting, colorTone, additionalDescription,
        mainImage, mainImageMimeType, faceImage, faceImageMimeType 
      } = options;

      const systemInstruction = `You are an expert prompt engineer for AI image generators. 
Your task is to analyze the provided images (if any) and combine them with the user's selected options to create a high-quality, detailed English prompt for image generation.

If images are provided:
- Analyze the character's appearance, clothing, and features from the main image.
- If a face image is provided, focus on the facial details and expressions.

Incorporate the following parameters into the prompt:
- Gender/Character Type
- Facial Expression
- Shot Type
- Camera Angle
- Character Pose
- Background/Location
- Art Style
- Lighting
- Color Tone
- Any additional descriptions.

Output ONLY the final prompt text in English.`;

      const parts: any[] = [];

      if (mainImage && mainImageMimeType) {
        parts.push({
          inlineData: {
            mimeType: mainImageMimeType,
            data: mainImage.split(',')[1],
          },
        });
      }

      if (faceImage && faceImageMimeType) {
        parts.push({
          inlineData: {
            mimeType: faceImageMimeType,
            data: faceImage.split(',')[1],
          },
        });
      }

      const promptText = `Generate a professional image generation prompt based on these settings:
- Gender: ${gender || 'Not specified'}
- Expression: ${expression || 'Not specified'}
- Shot Type: ${shotType || 'Not specified'}
- Camera Angle: ${cameraAngle || 'Not specified'}
- Pose: ${pose || 'Not specified'}
- Background: ${background || 'Not specified'}
- Art Style: ${artStyle || 'Not specified'}
- Lighting: ${lighting || 'Not specified'}
- Color Tone: ${colorTone || 'Not specified'}
- Additional Info: ${additionalDescription || 'None'}`;

      parts.push({ text: promptText });

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: { parts },
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error('Server Error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files from dist in production
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
