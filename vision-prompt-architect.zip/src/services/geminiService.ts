import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({ apiKey: apiKey! });

export interface PromptOptions {
  gender?: string;
  expression?: string;
  shotType?: string;
  cameraAngle?: string;
  pose?: string;
  background?: string;
  artStyle?: string;
  lighting?: string;
  colorTone?: string;
  additionalDescription?: string;
  mainImage?: string; // base64
  mainImageMimeType?: string;
  faceImage?: string; // base64
  faceImageMimeType?: string;
}

export async function generateImagePrompt(options: PromptOptions) {
  try {
    const response = await fetch('/api/generate-prompt', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(options),
    });

    if (!response.ok) {
      const errorData = await response.json() as any;
      throw new Error(errorData.error || 'Failed to generate prompt');
    }

    const data = await response.json() as any;
    return data.text || "Failed to generate prompt.";
  } catch (error: any) {
    console.error('Error calling Cloudflare Function:', error);
    return `Error: ${error.message}`;
  }
}
